
Responder-Login
-----------
Responder-Login is a simple Login/Logout management.
The basic structure of this is based on Flask-Login


